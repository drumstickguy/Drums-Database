7c291yqre13wr.exe by NindowsCahel132
A hard malware developeds 8 payload a few time?
The non-safety version will destructions your PC hard any dangerous!
Credits to ArTicZera and wipet for the HSL
Credits to fr4ctalz for the 1st bytebeat, but I modified it
This malware contains flashing lights & earrape, NOT for epilepsy
If you want to run it on Windows XP-11, then use if Win32 trojan version or it won't virus!!