█▀▀ █▀▀ █▀▀ ▀█▀ █░█░█ █░█ ░░█ █▀▀ ▀█ █▀█ █▀▀ █░█░█ █▀▄▀█ █▀▄ █░█░█
█▄▄ ██▄ █▄▄ ░█░ ▀▄▀▄▀ ▀▄▀ █▄█ █▀░ █▄ █▄█ ██▄ ▀▄▀▄▀ █░▀░█ █▄▀ ▀▄▀▄▀
Created by Marlon2210
Language programming: C++
Derstructive: Yes
The non-safety will corrupt the MBR
I'm NOT responsible for ANY damages!
Works in Windows Vista, 7, 8, 8.1, 10, and 11










































Credits to NotCCR and VenraTech for some effects made from dll.exe