Xenora.exe by Mr Grouse

A 10 payload and bytebeat
Skidded Mythlas shader!
Rate damage: Destructive

Creation date : February 8, 2025

Yes, it's skidded

Mario MBR