noni.exe
A date-timed trojan malware made in C++ over the course of a few minutes
Requires an x64 architecture to run.
Works on Windows XP-11
Credits to Nuclear.malware for the bytebeat and date checking function, but I modified the bytebeat
Creation date: June 7th 2025