Tested only on Windows 10
This is a harmless malware called protoxic.exe
Made by anotheraccount
The icon was inspired by VenraTech's malwares
Credits to malsteve527 for his Hue shift function
Epilepsy warning!
Made in Dev-C++
For skidders: please credit to me if you use the source code!

idk what else to put here...