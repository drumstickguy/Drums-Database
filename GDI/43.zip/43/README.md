### ℹ️ **Info**  
1. The malware is written in **C#**, and the **MBR** is coded in **Assembly**.  
2. It was entirely developed by **MalwareLab150 aka 2.0** for **nFire** (an Italian YouTuber).  
3. nFire tests malware on **virtual machines** **for educational purposes only**.  
https://www.youtube.com/@MalwareLab150/videos
aka 
https://www.youtube.com/@MalWareTesTer4._57/videos
---

### ⚠️ **Payloads?**  
4. **Corrupts disks** and **encrypts files** inside them.  
5. **Gradually corrupts all Windows registry keys** to avoid immediate crashes.  
6. **Overwrites almost all files in** `C:\Windows\System32` with random bytes  
7. **Encrypts files in the driver folder** (`C:\Windows\System32\Drivers`).  
8. **Damages disk partitions**.  
9. **Encrypts a significant portion of user profile files**.  
10. **Damages many system DLLs**.  
11. **Overwrites the MBR**, making the Os Unbootable.  
12. **Makes it impossible to reinstall Windows by killing the main disk (is a secret but i used Asm.)**.  
13. **Destroys the user profile** by deleting the `winlogon` and `svchost` registry keys.  
14. **GDI+3D payloads+ bytebeat**
---

### ❤️ **Beta Testers**  
1. **Adriano Tech** (first beta tester)  
   - GitHub: [Adrik-LOL](https://github.com/Adrik-LOL)  
   - YouTube: [Channel](https://www.youtube.com/channel/UCYUK8aH_6pRH9NlYH-FBpIA)  

2. **Leo Chrom**  
   - YouTube: [Channel](https://www.youtube.com/channel/UC9wveBeX8_d55HaTfkELt2w)  

3. **OneFive_Malware**  
   - YouTube: [Channel](https://www.youtube.com/channel/UCQ3R6zoo4MdWpnfg9h2qvug)  

4. **Ciberboy**  
   - YouTube: [Channel](https://www.youtube.com/@ciberboyYT/videos)  
   - GitHub: [Profile](https://github.com/CiberBoyYT)  

5. **Ponik aka Silver**  
   - YouTube: [Channel](https://www.youtube.com/channel/UCyag58Ji7QnTOpfTQnHCrKg)  

6. **Aniko**  
   - GitHub: [Profile](https://github.com/aniko33)  

7. **Ares Amigos**  
   - GitHub: [Profile](https://github.com/AresAmigos)  

8. **Vyac**  
   - YouTube: [Channel](https://www.youtube.com/channel/UCu1Um5BMKcXH1aU2nzctjcQ)
   - 
9. **Arrow.dll aka Giuse**  
   - GitHub: [Arrow1104](https://github.com/Arrow1104)  
   - YouTube: [Channel](https://www.youtube.com/channel/UCWhfYwcPd-Vm-fAF4jJZSwQ)  
   - Instagram: [giusen04](https://www.instagram.com/giusen04)  
   - TikTok: [@arrow1104](https://www.tiktok.com/@arrow1104)

10. **Tronco**  
   - TikTok: [@il.tuo_tronco.di.fiducia](https://www.tiktok.com/@il.tuo_tronco.di.fiducia)

11. **Viperine aka Win32 Viperine**  
   - GitHub: [Viperine-IT](https://github.com/Viperine-IT?tab=followers)

12. **Alloyd**  
   - GitHub: [Alloyd031](https://github.com/Alloyd031)  
   - YouTube: [Channel](https://www.youtube.com/@Alloyd031)

13. **AG5516**  
   - YouTube: [Channel](https://www.youtube.com/channel/UCL1TGWyc3dMyRQl3q7lXv-g)

14. **Niko**  
   - YouTube: [Channel](https://www.youtube.com/channel/UCXVSeHV8U9mZBerrKttsvAA)

15. **WindowsLab aka Erik**  
   - YouTube: [Channel](https://www.youtube.com/@windowslab-k9o)

16. **PIENNU**  
   - YouTube: [Channel](https://www.youtube.com/channel/UC2vkUJsWbd5vOyOjALPyrRQ)
.

Thanks to my friends:
Win32.Viperine,AdrianoTech,Radu,Arrow.dll,CiberBoy,Tronco,ChirLol ,Martix, Samix10, ClutterTech, inside2000, Alloyd,Radu Minecraft, PIENNU, Comium
,AleTech ,Il tizio,Aeos,Vichingo455,Aniko,
Ultimate Riser aka Ares Amigos ,AleX-1337,
Matteo Galli,Zerium,Anto,hyxn011💻,bugsbunny3013,Assistente Google,Erik aka WinLab
etc...
