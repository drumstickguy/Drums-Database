xA5qw69ebixA5qw69ebixA5qw69ebixA5qw69ebixA5qw69ebixA5qw69ebixA5qw69ebixA5qw69ebixA5qw69ebixA5qw69eb
i                   ______ ______         __     __         _______ ______                        e
b  .-----.--.--.--.|    __|  __  |.-----.|  |--.|__|.--.--.|   _   |    __|  .-----.--.--.-----.  9
e  |  _  |  |  |  ||  __  |__    ||  -__||  _  ||  ||_   _||       |__    |__|  -__|_   _|  -__|  6
9  |__   |________||______|______||_____||_____||__||__.__||___|___|______|__|_____|__.__|_____|  w
6     |__|                                                                                        q
w                                                                                                 5
qw69ebixA5qw69ebixA5qw69ebixA5qw69ebixA5qw69ebixA5qw69ebixA5qw69ebixA5qw69ebixA5qw69ebixA5qw69ebixA

Author(s): UltraDasher965 & N17Pro3426
Made in: C++
Damage rate: Destructive
Compatibility: Windows XP-11 (XP is recommended)
Number of payloads: 10

This malware contains flashing lights and loud sounds.
We do not recommend running the malware if you have photosensitive epilepsy or are scared of disturbing noises.
We also do not recommend running the destructive version on your physical hard drive, except if it's for educational and entertainment purposes.
Otherwise, run that version on a safe environment or if you don't have one, run the safety version on your physical hard drive.
That version won't do anything.

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  _  _ ____ _  _ ____    ____ _  _ _  _    ___ ____ ____ ___ _ _  _ ____    ___ _  _ ____    _  _ ____ _    _ _ _ ____ ____ ____    //
//  |__| |__| |  | |___    |___ |  | |\ |     |  |___ [__   |  | |\ | | __     |  |__| |___    |\/| |__| |    | | | |__| |__/ |___ |  //
//  |  | |  |  \/  |___    |    |__| | \|     |  |___ ___]  |  | | \| |__]     |  |  | |___    |  | |  | |___ |_|_| |  | |  \ |___ .  //
//                                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////