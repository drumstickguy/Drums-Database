~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 _  _ \/  _|  __ o  _|   _        _  _|_ |   \/ |  |    _      _   __ o |   _    __  |    _      \/ |  __     |   _  _        _      _      _ 
 |--|  | (_|_ |  | (_|_ [_] |\/| (/_  |_ |-|  | |_ |-| (/_ >< |_|_ _\ | |_ |_|_  |-' |-| (/_ |\|  | |_ _\ |_| |_ |- |_|_ |\| (/_ o  (/_ >< (/_
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Author(s): UltraDasher965 & N17Pro3426
Made in: C++
Number of payloads: 15

We recommend you to run the destructive version on a virtual machine with a snapshot or in a safe environment.
If you don't have a virtual machine, you can run the safety version in your main PC since it won't do any damage.
This malicious program was created ONLY for educational and entertainment purposes!
We are NOT responsible for ANY damages this can cause if you accidentally ran the destructive version of the malware itself.