MUVCrack.exe by Maxi Toys, But remastered by Jazzstuff
This can harm your device! Me and Maxi will not be responsible for anything caused.
 

Fun fact: If you press a key in the MBR, something happens! :)
So figure it out.