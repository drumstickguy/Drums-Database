OAO 1657-415.exe

Malware name: OAO 1657-415
Malware type: Trojan
Damage rate: Destructive
Works best in: Windows 2000 or newer
Made in: Dev-C++
Malware author: Comium92
Do NOT run it on your real PC, the creator is NOT responsible for ANY damages!