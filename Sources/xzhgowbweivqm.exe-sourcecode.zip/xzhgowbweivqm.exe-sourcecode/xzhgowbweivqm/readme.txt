xzhgowbweivqm.exe by Executioner
Yep. another 20th payload malware which took a day longer than Phoenix.

Phoenix took 4 days, while this one took 5 days.
There was creation hell at times like x64 change causing errors, but it turned out good in the end.
I have NOT tried the safety version. so I do not condone running it until N17Pro3426 checks it or tests it.

My channel: https://www.youtube.com/@katie-7px (i added it here cuz why not xdde)