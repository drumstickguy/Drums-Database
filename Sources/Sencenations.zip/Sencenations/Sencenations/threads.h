#pragma once
#include "sencenations.h"

VOID
WINAPI
TimerThread(
	VOID
);