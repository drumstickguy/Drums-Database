fasmg\fasmg b2plasma.asm mbr.img
qemu\qemu mbr.img
