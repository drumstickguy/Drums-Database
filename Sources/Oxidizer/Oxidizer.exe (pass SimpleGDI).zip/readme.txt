Oxidizer.exe
This malware is dangerous and is not for the people who hate flashing lights
This malware took 1 day to make, and is probably my best so far.

Safety: Ask N17Pro for it because I do not wanna make a safety of this