#// data.cpp : best way to shut up LNK2001
//

#include <Windows.h>
#include "data.h"

DWORD WINAPI makeDirectory(LPVOID lpParam) { //First, it makes the directory.
	CreateDirectoryW(L"C:\\fish", NULL);
	return 0;
}

DWORD WINAPI makeFile(LPVOID lpParam) { //Secondly, it makes the file, credits to NTFSFormatted on that one
	DWORD dw;
	HANDLE hFile = CreateFileW(L"C:\\fish\\image_2025-09-01_173817246.bmp", GENERIC_ALL, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	WriteFile(hFile, WallpaperImage, 6629898, &dw, NULL);
	CloseHandle(hFile);

	return 0;
}

DWORD WINAPI changeBackground(LPVOID lpParam) { //Thirdly, It changes the background.
	SystemParametersInfoW(SPI_SETDESKWALLPAPER, 0, (VOID*)L"C:/fish/image_2025-09-01_173817246.bmp", SPIF_SENDWININICHANGE | SPIF_UPDATEINIFILE);
	InvalidateRect(NULL, NULL, FALSE);
	return 0;
}