﻿// background.cpp : zwpapeiaziwhswna's background function
//

#include <Windows.h>
#include "data.h"

int CALLBACK WinMain(
	HINSTANCE hInstance, HINSTANCE hPrevInstance,
	LPSTR     lpCmdLine, int       nCmdShow
)
{
	CreateThread(0, 0, makeDirectory, 0, 0, 0);
	Sleep(2000);
	CreateThread(0, 0, makeFile, 0, 0, 0);
	Sleep(5000);
	CreateThread(0, 0, changeBackground, 0, 0, 0);
	Sleep(INFINITE);
}