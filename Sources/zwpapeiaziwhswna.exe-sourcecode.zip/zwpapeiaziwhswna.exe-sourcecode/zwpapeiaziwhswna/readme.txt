zwpapeiaziwhswna (noniRemastered) by VenraTech
Yep, another date timed trojan. Noni was shit so I decided to remaster it ;)

Suggested OS: Windows 10 or Windows 11 (cuz background payload gyrifodgijfoek)
If you are someone like Crypto NWO, please read "times.txt" to actually get everything working.