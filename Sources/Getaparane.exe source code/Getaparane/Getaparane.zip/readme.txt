Getaparane.exe by pankoza

A very long C++ GDI Malware (has 17 payloads, lasts 9 minutes, even longer than btfoiuthns, my longest malware so far)
This is very dangerous for the non-safety version, the non-safety version will damage the MBR, and make the PC unusable
on Windows Vista and newer it will also corrupt Boot\BCD
Works on Windows XP-11 but especially well on XP, Vista and 7
Both versions contain flashing lights and loud sounds, so it's not for people with epilepsy!
I'm not responsible for any damages.
Credits to ArTicZera and Wipet for the HSL RGBQUAD
Credits to ArTicZera and Rekto for the blur effect
Credits to GetMBR for the Hue Function (used for the triangles and the bouncing pie)
Creation date: September 23 2023

Thanks to fr4ctalz for the base for some HSL shaders

I recommend you to use a wallpaper that doesn't consist mostly of white and/or black color, because otherwise you won't see the HSL Shaders well

bugs: it might crash itself on XP due to bugs in the bytebeat













































Hi fr4ctalz, N17Pro3426, RainflowBoi and Crypto NWO, if you are reading this, hi





























