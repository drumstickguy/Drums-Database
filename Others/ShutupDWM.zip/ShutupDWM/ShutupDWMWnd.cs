﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using static ShutupDWM.ShutupDWM;

namespace ShutupDWM
{
    public partial class ShutupDWMWnd : Form
    {
        /// <summary>
        /// Initialize the Window Form
        /// </summary>
        public ShutupDWMWnd()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Check if the operating system is Vista or 7
        /// </summary>
        /// <returns></returns>
        private static bool IsVistaOrWin7()
        {
            Version os = Environment.OSVersion.Version;
            return (os.Major == 6 && (os.Minor == 0 || os.Minor == 1));
        }

        /// <summary>
        /// If user hits the "Exit program"
        /// We actually exit the program using ExitProcess( 0 );
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnExit_Click(object sender, EventArgs e)
        {
            ExitProcess(0);
        }

        /// <summary>
        /// Actual purpose of the program
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDisable_Click(object sender, EventArgs e)
        {
            if (!IsVistaOrWin7())
            {
                MessageBox.Show("This action cannot be completed on systems that are not Vista or 7.\nPlease try again on a Windows Vista/7 computer.", "ShutupDWM", MessageBoxButtons.OK, MessageBoxIcon.Error);
                ExitProcess(0);
            }

            int nDisablingResult = DwmEnableComposition(DWM_EC_DISABLECOMPOSITION);
            MessageBox.Show("DWM sucessfully disabled!", "ShutupDWM", MessageBoxButtons.OK, MessageBoxIcon.Information);
            ExitProcess(0);
        }
    }
}
