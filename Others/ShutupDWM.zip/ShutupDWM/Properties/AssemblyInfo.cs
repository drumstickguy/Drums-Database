﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("ShutupDWM")]
[assembly: AssemblyDescription("Turn off Windows Aero for Windows Vista/7")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("ListopadTheCat")]
[assembly: AssemblyProduct("ShutupDWM")]
[assembly: AssemblyCopyright("Copyright © ListopadTheCat")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible
// to COM components.  If you need to access a type in this assembly from
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("33fa2514-daed-4f52-a26c-29a42579f509")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version
//      Build Number
//      Revision
//
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
