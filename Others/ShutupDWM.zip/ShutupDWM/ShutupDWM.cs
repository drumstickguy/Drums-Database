﻿using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Security.Principal;

namespace ShutupDWM
{
    internal class ShutupDWM
    {
        [DllImport("dwmapi.dll")]
        public static extern int DwmEnableComposition(uint uCompositionAction);

        [DllImport("kernel32.dll")]
        public static extern void ExitProcess(uint uExitCode);

        public const uint DWM_EC_DISABLECOMPOSITION = 0;
        public const uint DWM_EC_ENABLECOMPOSITION = 1;
    }
}
